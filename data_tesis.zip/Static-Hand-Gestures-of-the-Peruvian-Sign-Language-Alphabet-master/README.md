# Static-Hand-Gestures-of-the-Peruvian-Sign-Language-Alphabet
Includes the 24 static gestures of the peruvian sign language alphabet. This dataset contains 150 images for each gesture with variations in rotation and scale
